# TD NF26: stockage clef/valeur (partie 1)

## [Sujet](./td_key_value_part1.pdf) du TD

## Prérequis

* `python3.9`
* `pipenv`
* `pre-commit`
* `make`

Tout est disponible et fonctionnel sur les serveurs de l'UV.
