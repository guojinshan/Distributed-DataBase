class CrudMissingKeyException(Exception):
    pass


class CrudKeyAlreadyExistsException(Exception):
    pass
